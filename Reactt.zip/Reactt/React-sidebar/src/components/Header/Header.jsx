import React from "react";
import header from "/home/hasan/Desktop/ooo/React-sidebar/src/assets/Images/header.png";
import "./Header.css";

function Header() {
  return (
    <div className="header-container ">
      <img src={header} alt="header" />
    </div>
  );
}

export default Header;
