import React from "react";
import "/home/hasan/Desktop/ooo/React-sidebar/src/components/components.css";
function Teachers() {
  return <div className="component-container">assala</div>;
}

export default Teachers;
