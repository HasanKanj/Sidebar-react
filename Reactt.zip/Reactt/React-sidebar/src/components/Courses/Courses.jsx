import React from "react";
import "/home/hasan/Desktop/ooo/React-sidebar/src/components/components.css";

function Courses() {
  return <div className="component-container">omar</div>;
}

export default Courses;
