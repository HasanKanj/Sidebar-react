import React from "react";
import "/home/hasan/Desktop/ooo/React-sidebar/src/components/components.css"
function Home() {
  return <div className="component-container">asdasdsadsadsasdasdasdasadas</div>;
}

export default Home;
