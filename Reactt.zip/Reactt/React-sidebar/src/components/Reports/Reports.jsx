import React from "react";
import "/home/hasan/Desktop/ooo/React-sidebar/src/components/components.css"

function Reports() {
  return <div className="component-container">hasan</div>;
}

export default Reports;
