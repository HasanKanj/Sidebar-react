import React from "react";
import "/home/hasan/Desktop/ooo/React-sidebar/src/components/components.css";

function Classes() {
  return <div className="component-container">maya</div>;
}

export default Classes;
