import React from "react";
import "/home/hasan/Desktop/ooo/React-sidebar/src/components/components.css";

function Attendance() {
  return <div className="component-container">sdfdsasdasdasasfs</div>;
}

export default Attendance;
